package phmr;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.schematron.ant.SchematronReport;
import com.schematron.ant.SchematronResult;
import com.schematron.ant.Validator;
import com.schematron.ant.ValidatorFactory;

/**
 * Servlet implementation class ProcessServlet
 */
@WebServlet("/ProcessServlet")
public class ProcessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcessServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fileFolder = "/uploads";
		ServletContext context = request.getSession().getServletContext();
		String realFileFolder = context.getRealPath(fileFolder);  

		try{
			MultipartRequest multipartRequest = new MultipartRequest(request,realFileFolder,5*1024*1024,
		            "utf-8",new DefaultFileRenamePolicy());
			Enumeration<?> files = multipartRequest.getFileNames();
			
			String type = multipartRequest.getParameter("type");
			
			if(type == null) type="none";
			
			if(type.equals("phmrcda")){
				processPHMR(request, multipartRequest, files);
			} else if(type.equals("cdaccd")){
				processCDA(request, multipartRequest, files);
			}
			
		} catch(Exception e){
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);
	}

	private void processPHMR(HttpServletRequest request, MultipartRequest multipartRequest, Enumeration<?> files) throws ServletException, IOException{
		String result="valid";
		// uploaded file
		String filename ="";
		String fileFolder = "/uploads"; // file folder
		String realFileFolder = ""; // absolute path of web application
		// schematron file
		String schematronFolder="/schematrons/phmr";
		String schemaFile = "PHMR.sch";
		String realSchemaFolder="";
		ArrayList<ResultBean> uploadedFiles = null;
		System.setProperty("javax.xml.transform.TransformerFactory",
		          "net.sf.saxon.TransformerFactoryImpl");
		ValidatorFactory factory = new ValidatorFactory("xslt2", "svrl" );
	    factory.setDebugMode(true);
	    factory.setErrorListener(new SchematronErrorListener());
		
		request.setCharacterEncoding("utf-8");
		
		ServletContext context = request.getSession().getServletContext();
		realFileFolder = context.getRealPath(fileFolder);  
		realSchemaFolder = context.getRealPath(schematronFolder);
		
		String schema = realSchemaFolder + "/" + schemaFile;
		Source source = new StreamSource(schema);
		
		
		try{
			
			if(files == null){
				return;
			}
			
			Validator validator = factory.newValidator(source);
			//파일 정보가 있다면
			if(files.hasMoreElements()){
				uploadedFiles = new ArrayList<>();
			}
			while(files.hasMoreElements()){
		       String name = (String)files.nextElement();
		       filename = multipartRequest.getFilesystemName(name);

		       // Validation
		       StreamSource xml =new StreamSource(realFileFolder + "/" + filename);
		       SchematronResult schematronResult = validator.validate(xml, "", "", "", "", "utf-8");
		       SchematronReport report = new SchematronReport();
		       report.add(schematronResult);
		       File resultFile = new File(realFileFolder, filename+"_result.xml");
		       report.saveAs(resultFile );
		       
		       ResultBean bean = new ResultBean();
		       bean.setFileName(multipartRequest.getOriginalFileName(name));
	    	   bean.setResultFile("uploads/"+ resultFile.getName());
	    	   // Find Error Messages from result. and add to bean
	    	   bean.addErrorMessage(schematronResult.getSVRLAsString());
		       uploadedFiles.add(bean);
		     }
		     request.setAttribute("uploaded", uploadedFiles);
		     
		  }catch(Exception e){
		     e.printStackTrace();
		     result="upload-error: Too big file.";
		  } finally {
			 request.setAttribute("result", uploadedFiles);
		  }
	}
	
	private void processCDA(HttpServletRequest request, MultipartRequest multipartRequest, Enumeration<?> files) throws ServletException, IOException{
		ServletContext context;
		// file upload related
		String fileFolder = "/uploads"; // file folder
		String realFileFolder = ""; // absolute path of web application
		// absolute path for schema(xsd)
		String schemaFolder="/schemas/CDASchemas/cda/Schemas";
		String schemaFileName = "CDA.xsd";
		String realSchemaFolder="";
		// absolute path for schematron(sch)
		String schematronFolder="/schematrons/ccd";
		String schematronFileName="ccd.sch";
		String realSchematronFolder="";
		// result files
		String fileName;
		ArrayList<ResultBean> uploadedFiles = null;
		
		Schema schema;
		// Schema: xsd file
		SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		// Schematron: sch file
		ValidatorFactory schematronFactory = new ValidatorFactory("xslt2", "svrl" );
	    schematronFactory.setDebugMode(true);
	    schematronFactory.setErrorListener(new SchematronErrorListener());
		
		request.setCharacterEncoding("utf-8");
		
		context = request.getSession().getServletContext();
		realFileFolder = context.getRealPath(fileFolder); 
		realSchemaFolder = context.getRealPath(schemaFolder);
		realSchematronFolder = context.getRealPath(schematronFolder);
		String schemaPath = realSchemaFolder + "/" + schemaFileName;
		String schematronPath = realSchematronFolder + "/" + schematronFileName;
		
		Source source = new StreamSource(schematronPath);	
		
		try{
			if(files == null){
				return;
			}
			com.schematron.ant.Validator schematronValidator = schematronFactory.newValidator(source);
			//파일 정보가 있다면
			if(files.hasMoreElements()){
				uploadedFiles = new ArrayList<>();
			}
			while(files.hasMoreElements()){
		       String name = (String)files.nextElement();
		       fileName = multipartRequest.getFilesystemName(name);
		       
		       ResultBean bean = new ResultBean();
		       bean.setFileName(multipartRequest.getOriginalFileName(name));
		       uploadedFiles.add(bean);
		       
		       StreamSource xsd =new StreamSource(schemaPath);
		       StreamSource xml = new StreamSource(realFileFolder + "/" + fileName);
		       schema = schemaFactory.newSchema(xsd);
		       javax.xml.validation.Validator schemaValidator = schema.newValidator();
		       schemaValidator.validate(xml);
		       
		       SchematronResult schematronResult = schematronValidator.validate(xml, "", "", "", "", "utf-8");
		       SchematronReport report = new SchematronReport();
		       report.add(schematronResult);
		       File resultFile = new File(realFileFolder, fileName+"_result.xml");
		       report.saveAs(resultFile );
		       bean.setResultFile("uploads/"+ resultFile.getName());
		       bean.addErrorMessage(schematronResult.getSVRLAsString());
			}
		}catch(Exception e){
		     e.printStackTrace();
		     uploadedFiles.get(uploadedFiles.size()-1).addErrorMessage(e.getMessage());
		}finally{
			request.setAttribute("result", uploadedFiles);
		}
	}
}
