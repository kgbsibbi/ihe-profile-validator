package phmr;

import java.util.ArrayList;

public class ResultBean {
	private String fileName;
	private String resultFile;
	private ArrayList<String> errorMessages;
	
	public ResultBean(){
		errorMessages = new ArrayList<>();
	}
	public String getResultFile() {
		return resultFile;
	}
	public void setResultFile(String resultFile) {
		this.resultFile = resultFile;
	}
	public ArrayList<String> getErrorMessages() {
		return errorMessages;
	}
	public void setErrorMessages(ArrayList<String> errorMessages) {
		this.errorMessages = errorMessages;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}	
	public void addErrorMessage(String message){
		errorMessages.add(message);
	}
}
